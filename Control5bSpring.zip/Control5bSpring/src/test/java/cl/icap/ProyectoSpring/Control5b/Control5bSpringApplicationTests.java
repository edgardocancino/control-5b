package cl.icap.ProyectoSpring.Control5b;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Control5bSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
