function GolesController(option){
	$("#msg").hide();
	$("#msg").removeClass("alert-success").addClass("alert-danger");
	var token = $("meta[name='_csrf']").attr("content");
	
	switch(option){
	case "list":
		$.ajax({
			type : "post",
		    headers: {"X-CSRF-TOKEN": token}, //send CSRF token in header
			url : "/goles/list",
			success : function(res) {
				$('#golestable').bootstrapTable('load', res);
				$('#golestable tbody').on('click', 'tr', function () {
					$("#jug_rut").val($(this).find("td:eq(0)").text());
					$("#gol_cantidad").val($(this).find("td:eq(1)").text());
					$("#jug_nombre").val($(this).find("td:eq(2)").text());
					});
				$("#mymodal").modal({show:true});
			},
			error : function() {
				$("#msg").show();
				$("#msg").html("Error en busqueda de notas.")
			}
		});       			
		break;
	case "get":
		$.ajax({
			type : "post",
		    headers: {"X-CSRF-TOKEN": token}, //send CSRF token in header
			url : "/goles/get",
			data : "jug_rut="+$("#jug_rut").val(),
			success : function(res) {
				if (res == null || res == "") {
					$("#msg").show();
					$("#msg").html("No se encontraron registros.");
				} else {	
					$("#jug_rut").val(res.jug_rut);
					$("#gol_cantidad").val(res.Gol_cantidad);
					$("#jug_nombre").val(res.jug_nombre);
					
					}
			},
			error : function() {
				$("#msg").show();
				$("#msg").html("Error en busqueda.");
			}
		});       			
		break;
	case "insert":
		$("#jug_rut").val(0),
		$("#gol_cantidad").val(0),
		$("#jug_nombre").val(" "),
		
		break;
	case "update":
		var json = 
			{
				'jug_rut': $("#jug_rut").val(),
				'gol_cantidad': $("#gol_cantidad").val(),
				'jug_nombre': $("#jug_nombre").val(),
				
			};

		var postData = JSON.stringify(json);

		$.ajax({
			type : "post",
		    headers: {"X-CSRF-TOKEN": token}, //send CSRF token in header
			url : "/goles/update",
			data : postData,
			contentType : "application/json; charset=utf-8",
			dataType : "json",
			success : function(res) {
				if (res == 1) {
					$("#msg").removeClass("alert-danger").addClass("alert-success");
					$("#msg").show();
					$("#msg").html("Registro modificado correctamente.");
				} else {
					$("#msg").show();
					$("#msg").html("No se pudo modificar el registro.");
				}
			},
			error : function() {
				$("#msg").show();
				$("#msg").html("No se pudo modificar el registro.");
			}
		});       	
    break;
	case "delete":
		$.ajax({
			type : "post",
		    headers: {"X-CSRF-TOKEN": token}, //send CSRF token in header
			url : "/goles/delete",
			data : "jug_rut="+$("#jug_rut").val(),
			success : function(res) {
				if (res == 1) {
					$("#msg").removeClass("alert-danger").addClass("alert-success");
					$("#msg").show();
					$("#msg").html("Registro eliminado correctamente.");
				} else {
					$("#msg").show();
					$("#msg").html("No se pudo eliminar el registro.");
				}
			},
			error : function() {
				$("#msg").show();
				$("#msg").html("No se pudo eliminar el registro.");
			}
		});
		break;
	default:
		$("#msg").show();
		$("#msg").html("Opción incorrecta.");
	}
}
