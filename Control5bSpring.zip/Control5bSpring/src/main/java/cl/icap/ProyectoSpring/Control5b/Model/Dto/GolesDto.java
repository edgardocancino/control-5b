package cl.icap.ProyectoSpring.Control5b.Model.Dto;

public class GolesDto {

	private Integer jug_rut;
	private Integer gol_cantidad;
	private String jug_nombre;
	
	public GolesDto() {
			
	}

	public Integer getJug_rut() {
		return jug_rut;
	}

	public void setJug_rut(Integer jug_rut) {
		this.jug_rut = jug_rut;
	}

	public Integer getGol_cantidad() {
		return gol_cantidad;
	}

	public void setGol_cantidad(Integer gol_cantidad) {
		this.gol_cantidad = gol_cantidad;
	}

	public String getJug_nombre() {
		return jug_nombre;
	}

	public void setJug_nombre(String jug_nombre) {
		this.jug_nombre = jug_nombre;
	}
	
	
}


	