package cl.icap.ProyectoSpring.Control5b.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class webcontrol5bController  {
	
	@RequestMapping("/")	
	public String getHome() {
		return "home";
	}
	@RequestMapping("/index")	
	public String getIndex() {
		return "index";
	}
  
	@RequestMapping("/goles")	
	public String getgoles() {
		return "goles";
	}   
}