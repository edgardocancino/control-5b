package cl.icap.ProyectoSpring.Control5b.Service;

import java.util.List;

import cl.icap.ProyectoSpring.Control5b.Model.Dto.GolesDto;



public interface GolesService {
	
	public List<GolesDto> getgoles(Integer jug_rut);
	
	public int updategoles(GolesDto golesdto);

}
