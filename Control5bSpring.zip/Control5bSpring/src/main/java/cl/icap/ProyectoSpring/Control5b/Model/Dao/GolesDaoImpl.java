package cl.icap.ProyectoSpring.Control5b.Model.Dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import cl.icap.ProyectoSpring.Control5b.Model.Dto.GolesDto;



@Repository
@Transactional
public class GolesDaoImpl implements GolesDao {
	private String getgoles="SELECT * FROM GOLES WHERE JUG_RUT=?";
	private String updategoles="UPDATE GOLES SET JUG_RUT=?, GOL_CANTIDAD=? WHERE JUG_RUT=? AND JUG_NOMBRE=?";
	
	@Autowired
	JdbcTemplate jdbctemplate;
	
	@Override
	public List<GolesDto> getgoles(Integer jug_rut) {
		Object[] args= {jug_rut};
		return jdbctemplate.query(getgoles,args,new RowMapper<GolesDto>() {
			@Override
			public GolesDto mapRow(ResultSet rs, int rowNum) throws SQLException {
				GolesDto goles=new GolesDto();
				goles.setJug_rut(rs.getInt("jug_rut"));
				goles.setGol_cantidad(rs.getInt("gol_cantidad"));
				goles.setJug_nombre(rs.getString("jug_nombre"));
				return goles;
			}
			});
	}

	@Override
	public int updategoles(GolesDto golesdto) {
		int rows=0;
		Object[] args={
				golesdto.getJug_rut(),
				golesdto.getGol_cantidad(),
				golesdto.getJug_nombre()};
			
		try {
			rows=jdbctemplate.update(updategoles,args);
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		return rows;
	}
}
