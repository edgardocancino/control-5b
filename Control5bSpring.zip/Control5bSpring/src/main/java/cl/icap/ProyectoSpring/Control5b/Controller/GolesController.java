package cl.icap.ProyectoSpring.Control5b.Controller;

import java.io.IOException;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;


import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import cl.icap.ProyectoSpring.Control5b.Model.Dto.GolesDto;
import cl.icap.ProyectoSpring.Control5b.Service.GolesService;

@Controller
@RequestMapping(value="/goles")
public class GolesController {
	@Autowired
	GolesService golesservice;
	
	@RequestMapping(value="/updategoles")
	public @ResponseBody int ajaxupdategoles(HttpServletRequest req, HttpServletResponse res) {
		int rows=0;
		try {
			String RequestData = req.getReader().lines().collect(Collectors.joining());
			Gson gson = new GsonBuilder().setDateFormat("dd-mm-yy").create();
			GolesDto goles = gson.fromJson(RequestData, GolesDto.class);
			rows=golesservice.updategoles(goles);
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	return rows;	
	}
}
