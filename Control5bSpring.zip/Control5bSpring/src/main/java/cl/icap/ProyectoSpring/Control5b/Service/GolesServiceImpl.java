package cl.icap.ProyectoSpring.Control5b.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cl.icap.ProyectoSpring.Control5b.Model.Dao.GolesDao;
import cl.icap.ProyectoSpring.Control5b.Model.Dto.GolesDto;


@Service
public class GolesServiceImpl implements GolesService {

	@Autowired
	GolesDao golesdao;
	
	@Override
	public List<GolesDto> getgoles(Integer jug_rut) {
		return golesdao.getgoles(jug_rut);
	}

	@Override
	public int updategoles(GolesDto golesdto) {
		return golesdao.updategoles(golesdto);
	}

}
